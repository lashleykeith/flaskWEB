import googlemaps # pip install googlemaps
# import pandas as pd # pip install pandas
from pprint import pprint
from pathlib import Path
import time
import json




def miles_to_meter(miles):
	try:
		return miles * 1_609.344
	except:
		return 0


def get_city_category_datas(lat,lon,cat):
	API_KEY = open('API_KEY.txt', 'r').read()
	map_client = googlemaps.Client(API_KEY)

	print("*********************************************************************")
	print("Map Clip")
	pprint(dir(map_client))
	print("\n")
	print("\n")
	location = (lat,lon)
	search_string = cat
	distance = miles_to_meter(15)
	business_list = []

	response = map_client.places_nearby(
		location=location,
		keyword=search_string,
		radius=distance
	)

	business_list.extend(response.get('results'))
	next_page_token = response.get('next_page_token')

	while next_page_token:
		time.sleep(2)
		response = map_client.places_nearby(
			location=location,
			keyword=search_string,
			radius=distance,
			page_token=next_page_token
		)
		business_list.extend(response.get('results'))
		next_page_token = response.get('next_page_token')
	bb=[]
	for b in business_list:
		geo = b['geometry']
		lat1 = 0
		lat2 = 0
		distance = 1000000
		try:
			lat1 = float(geo.split('viewport')[0].split("'lat'")[1].split(',')[0].replace(':', '').strip())
			lon1 = float(geo.split('viewport')[0].split("'lng'")[1].split('}')[0].replace(':', '').strip())
			distance = (lat - lat1) ** 2 + (lon - lon1) ** 2
		except:
			pass
		photo=''
		try:
			photo = b['photos'][0]['photo_reference']
		except:
			pass
		stars = 0
		rating=0
		try:
			rating=b['rating']
			stars = int(b['rating'])
		except:
			pass
		price_level=''
		try:
			price_level=b['price_level']
		except:
			pass
		opening_hours=''
		try:
			opening_hours=b['opening_hours']
		except:
			pass
		types=[]
		try:
			types=b['types']
		except:
			pass
		vicinity=''
		try:
			vicinity=b['vicinity']
		except:
			pass


		print(stars)
		bb.append({
                      'bus_status':b['business_status'] if 'business_status' in b else 'for ',
                      'name':b['name'],
                      'geo':geo,
                      'distance':distance,
                      'hour':opening_hours,
                      'photo':photo,
                      'price_level':price_level,
                      'rating':rating,
                      'stars':['checked' for i in range(stars)]+['' for i in range(5-stars)],
                      'tags':types if len(types)<=4 else types[0:4],
                      'user_total_rating':b['user_ratings_total'] if 'user_ratings_total' in b else 0,
                      'address':vicinity,
                      'map':f'https://www.google.com/maps/place/?q=place_id:{b["reference"]}',
					  'row':b})
	return bb

def get_city_data_json(city_id,cat,lat,lon):
	print(f'check {city_id} {cat}')
	if Path(f'city_category_jsons/{city_id}_{cat}.json').exists():
		print('path found')
		with open(f'city_category_jsons/{city_id}_{cat}.json') as file:
			return json.loads(file.read())
	else:
		data=get_city_category_datas(lat,lon,cat)
		with open(f'city_category_jsons/{city_id}_{cat}.json','w') as file:
			file.write(json.dumps(data))
		return data
# print(business_list)



# https://www.youtube.com/watch?v=YwIu2Rd0VKM&list=PL3JVwFmb_BnQrh3CFjyxD4vfyZ7ovvDLK&index=4



