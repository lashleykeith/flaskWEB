import os
import json
import csv
from flask import Flask, render_template,redirect,request
import xlrd
from os import listdir
from os.path import isfile, join
from pathlib import Path
from data_retrieve import get_city_data_json
from flask_cors import CORS
# import pandas as pd

app = Flask(__name__,template_folder='templates')
CORS(app)
# app.config['CORS_HEADERS'] = 'Content-Type'
# @cross_origin()


cities=[]
def get_categories():
    onlyfiles = [f for f in listdir('categories') if isfile(join('categories', f)) and '$' not in f]
    categories=[]
    for cat_file in onlyfiles:
        photo=get_first_photo(cat_file)
        cat=cat_file.split('.xlsx')[0]
        categories.append({'name':cat,'photo':photo})
    return categories

def get_cities():
    global cities
    cities=[]
    with open('aus_cities.csv','r') as file:
        reader=csv.DictReader(file)
        for row in reader:
            city=json.loads(json.dumps(row))
            city['id']=int(city['id'])-1
            cities.append(city)
    return cities

def get_city(city_id):
    # global cities

    city = {"name": ""}   
    with open('aus_cities.csv','r') as file:
        reader=csv.reader(file)
        next(reader)
        for row in reader:
            if row[0].strip() == str(city_id):
                city["name"] = row[1].strip()
                break
    return city

def get_first_photo(cat_file):
    rows=get_excel_data(cat_file)
    for row in rows:
        if row['photo'].strip()!='':
            return row['photo']

def get_city_data(category,current_row=0,stop_after=-1,city_id=-1):
    data=[]
    if len(cities)==0:
        get_cities()
    # print(len(cities))
    if city_id!=-1:
        # print(city_id)
        data=get_city_data_json(city_id,category,cities[city_id]['latitude'],cities[city_id]['longitude'])
    else:
        for i in range(0,2):
            data.extend(get_city_data_json(i,category,cities[i]['latitude'],cities[i]['longitude']))
    if stop_after!=-1:
        data=data[current_row:stop_after]
    i=0
    for dat in data:
        dat['place_id']=i
        i+=1
    return data



def get_excel_data(category_file,current_row=1,stop_after=-1,longitude=-200.0,latitude=-200.0):
    sheet_num = 0
    input_total = 0
    output_total = 0
    src = f'categories/{category_file}'
    book = xlrd.open_workbook(src)
    # select the sheet that the data resids in
    work_sheet = book.sheet_by_index(sheet_num)
    # get the total number of rows
    num_rows = work_sheet.nrows - 1

    ind_bus_status = 0
    ind_geo = 1
    ind_name = 5
    ind_hours = 6
    ind_photo = 7
    ind_price_level = 8
    ind_rating = 11
    ind_tags = 14
    ind_user_rating = 15
    ind_address = 16
    ind_map_url = 17
    for j in range(0,20):
        header=''
        try:
            header=work_sheet.cell_value(0,j).lower()
        except:
            pass
        if header=='business_status':
            ind_bus_status=j
        elif header=='geometry':
            ind_geo=j
        elif header=='name':
            ind_name=j
        elif header=='opening_hours':
            ind_hours=j
        elif header=='photos':
            ind_photo=j
        elif header=='price_level':
            ind_price_level=j
        elif header=='rating':
            ind_rating=j
        elif header=='types':
            ind_tags=j
        elif header=='user_ratings_total':
            ind_user_rating=j
        elif header=='vicinity':
            ind_address = j
        elif header=='url':
            ind_map_url=j

    datas=[]
    while current_row < num_rows:
        if stop_after!=-1 and current_row>stop_after:
            break
        bus_state=work_sheet.cell_value(current_row,ind_bus_status)
        geo=work_sheet.cell_value(current_row,ind_geo)
        lat1=0
        lat2=0
        distance = 1000000
        if longitude>=-180 and latitude>=-180:
            try:
                lat1=float(geo.split('viewport')[0].split("'lat'")[1].split(',')[0].replace(':','').strip())
                lon1=float(geo.split('viewport')[0].split("'lng'")[1].split('}')[0].replace(':','').strip())
                distance=(latitude-lat1)**2 + (longitude-lon1)**2
            except:
                pass
        name=work_sheet.cell_value(current_row,ind_name)
        hour=work_sheet.cell_value(current_row,ind_hours)
        photo=''
        try:
            photo= work_sheet.cell_value(current_row, ind_photo).split("photo_reference':")[1].split(',')[0].replace("'",'')
        except:
            pass
        price_level=work_sheet.cell_value(current_row,ind_price_level)
        rating=work_sheet.cell_value(current_row,ind_rating)
        stars=0
        try:
            stars=int(work_sheet.cell_value(current_row,ind_rating))
        except:
            pass
        tags=[]
        try:
            tags=json.loads(work_sheet.cell_value(current_row,ind_tags).replace("'",'"'))
        except:
            pass
        user_total_rating=''
        try:
            user_total_rating=str(int(work_sheet.cell_value(current_row,ind_user_rating)))
        except:
            pass
        address=work_sheet.cell_value(current_row,ind_address)
        map=work_sheet.cell_value(current_row,ind_map_url)

        datas.append({
                      'place_id':current_row,
                      'bus_status':bus_state,
                      'name':name,
                      'geo':geo,
                      'distance':distance,
                      'hour':hour,
                      'photo':photo,
                      'price_level':price_level,
                      'rating':rating,
                      'stars':['checked' for i in range(stars)]+['' for i in range(5-stars)],
                      'tags':tags,
                      'user_total_rating':user_total_rating,
                      'address':address,
                      'map':map})
        current_row+=1
    if longitude>=-180 and latitude>=-180:
        datas = sorted(datas, key=lambda k: k['distance'])
        tolen = 20 if len(datas)>=20 else len(datas)
        datas = datas[0:tolen]
    datas = sorted(datas, key=lambda k: k['rating'],reverse=True)
    return datas


@app.route('/image')
def image():
    id=request.args.get('id')
    if id.strip()=='':
        return redirect('https://wallpaperaccess.com/download/plain-white-676549')
    return redirect(f"https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference={id}&sensor=false&key=AIzaSyAOwO6kQ5mUUt5N7w-fdB7CwVhrLtGX4PY", code=302)

@app.route('/map')
def map_image():
    geo=request.args.get('geo').replace("'",'"')
    name=request.args.get('name')
    # print(name)
    # print(geo)
    if geo.strip()=='':
        return redirect('https://wallpaperaccess.com/download/plain-white-676549')
    geo=json.loads(geo)
    # print(f"http://maps.google.com/maps/api/staticmap?center={geo['location']['lat']},{geo['location']['lng']}&zoom=11&size=512x512&markers=size:mid|color:red|label:restaurant|{geo['location']['lat']},{geo['location']['lng']}&sensor=false&key=AIzaSyAQVPi9bgsY5HtQrKi8t5H87RB1C78xhP0")
    return redirect(f"http://maps.google.com/maps/api/staticmap?center={geo['location']['lat']},{geo['location']['lng']}&zoom=11&size=512x512&markers=size:mid|color:red|label:restaurant|{geo['location']['lat']},{geo['location']['lng']}&sensor=false&key=AIzaSyAQVPi9bgsY5HtQrKi8t5H87RB1C78xhP0", code=302)

@app.route('/category/<cat>')
def cat_view(cat):
    city = -1
    try:
        city=int(request.args.get('city'))
    except:
        pass
    datas = get_city_data(cat, 0, -1, city)
    # print(datas)
    # print(len(datas))
    return render_template('cat_view.html', datas=datas,cities=get_cities(),select_city=city,cat=cat)

@app.route('/category/<cat>/place')
def place(cat):
    id = int(request.args.get('place_id'))
    city_id = -1
    try:
        city_id=int(request.args.get('city'))
    except:
        pass
    place=get_city_data(cat,id,id+1,city_id)[0]
    return render_template('place.html', place=place)

@app.route('/category')
def categories():
    return render_template('category.html', categories=get_categories(),cities=get_cities())

@app.route('/')
def home():
    return redirect('/category')

@app.route('/api/category')
def get_categories_api():
    response = app.response_class(
        response=json.dumps(get_categories()),
        status=200,
        mimetype='application/json'
    )
    response.headers.add("Access-Control-Allow-Origin", "*")
    return response

@app.route('/api/category/<cat>')
def get_specific_category_api(cat):
    city = -1
    try:
        city = int(request.args.get('city'))
    except:
        pass
    datas = get_city_data(cat, 0, -1, city)
    response = app.response_class(
        response=json.dumps(datas),
        status=200,
        mimetype='application/json'
    )
    response.headers.add("Access-Control-Allow-Origin", "*")
    return response

@app.route('/api/category/<cat>/place')
def get_place_api(cat):
    try:
        id = int(request.args.get('place_id'))
        city_id = -1
        try:
            city_id=int(request.args.get('city'))
        except:
            pass
        place=get_city_data(cat,id,id+1,city_id)[0]
    except:
        place = {'error':'Please send place id'}
    response = app.response_class(
        response=json.dumps(place),
        status=200,
        mimetype='application/json'
    )
    response.headers.add("Access-Control-Allow-Origin", "*")
    return response

@app.route('/api/city')
def get_city_api():
    try:
        city_id = int(request.args.get('id'))
    except:
        pass
    else:
        city = get_city(city_id+1)
        # print(city)
        response = app.response_class(
            response=json.dumps(city),
            status=200,
            mimetype='application/json'
        )
        response.headers.add("Access-Control-Allow-Origin", "*")
        return response

@app.route('/api/cities')
def get_cities_api():
    response = app.response_class(
        response=json.dumps(get_cities()),
        status=200,
        mimetype='application/json'
    )
    response.headers.add("Access-Control-Allow-Origin", "*")
    return response




if __name__ == '__main__':
    get_cities()
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
    #app.run(debug=True)


# gcloud builds submit --tag gcr.io/<project_id>/