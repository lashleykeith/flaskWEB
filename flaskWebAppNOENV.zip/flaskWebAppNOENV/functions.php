<?php
/**
 * Understrap functions and definitions
 *
 * @package understrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$understrap_includes = array(
	'/theme-settings.php',                  // Initialize theme default settings.
	'/setup.php',                           // Theme setup and custom theme supports.
	'/widgets.php',                         // Register widget area.
	'/enqueue.php',                         // Enqueue scripts and styles.
	'/template-tags.php',                   // Custom template tags for this theme.
	'/pagination.php',                      // Custom pagination for this theme.
	'/hooks.php',                           // Custom hooks.
	'/extras.php',                          // Custom functions that act independently of the theme templates.
	'/customizer.php',                      // Customizer additions.
	'/custom-comments.php',                 // Custom Comments file.
	'/jetpack.php',                         // Load Jetpack compatibility file.
	'/class-wp-bootstrap-navwalker.php',    // Load custom WordPress nav walker.
	'/woocommerce.php',                     // Load WooCommerce functions.
	'/editor.php',                          // Load Editor functions.
	'/deprecated.php',                      // Load deprecated functions.
);

foreach ( $understrap_includes as $file ) {
	$filepath = locate_template( 'inc' . $file );
	if ( ! $filepath ) {
		trigger_error( sprintf( 'Error locating /inc%s for inclusion', $file ), E_USER_ERROR );
	}
	require_once $filepath;
}


function my_script() {
?>

<script type="text/javascript">
var api_base = "http://localhost:8004"

var city_id = "<?php echo isset($_GET["city_id"]) ? $_GET["city_id"] : '-1'; ?>";
var city = "";
var category = "<?php echo isset($_GET["category"]) ? $_GET["category"] : '-1'; ?>";
var place_id = "<?php echo isset($_GET["place_id"]) ? $_GET["place_id"] : ''; ?>";
var place = {};
var page_temp = "<?php 
			$temp = basename(get_page_template()); 
			// $temp = str_replace(['page-', '.php'], '', $temp, 1);
			echo $temp; 
		?>";
var heading = document.getElementById("heading");
var paragraph = document.getElementById("paragraph");

var initHeader = function() {
  <?php if ($temp == 'page-city.php') { ?>
		heading.innerHTML = `Best places to visit in ${ city }`

  <?php } elseif ($temp == 'page-category.php') { ?>
		heading.innerHTML = `Top rated ${ category } in ${ city }`
		paragraph.innerHTML = `Ratings are based on <b> 625,133</b> people reviews from 1422 bars and
			pubs in the country. The average (of 1422 bars and pubs) rating score is
			<span class="badge badge-success">4.17</span>`

  <?php } elseif ($temp == 'page-place.php') { ?>
		
	<?php } else { ?>
		heading.innerHTML = 'Discover the most reviewed places in your city'
		heading.setAttribute('style', 'font-weight: 700; letter-spacing: -1px; line-height: 1.1em;')
		// paragraph.innerHTML = 'Restaurants, Tourist Attractions, Hotels, Bars & Pubs based on ratings of Google Maps'
		paragraph.innerHTML = 'Pozzies is the largest network of people leaving positive reviews for businesses. We can link your business to the thousands of Pozzies ready to leave a positive review for your business.'
		// paragraph.setAttribute('style', '')

	<?php } ?>
}

var initCategories = function(categories) {

  var mainEl = document.getElementById("categories")

  // var allCats = document.createElement('DIV')
  // allCats.setAttribute('class', 'col-12')
  // allCats.innerHTML = 
  //   `<a href="<?php echo get_site_url(); ?>/category?city_id=${city_id}&category=-1" class="text-dark card-wrapper">
  //     <div class="card my-2 mx-md-2" style="">
  //       <div class="card-body">
  //         <p class="card-text"></p>
  //         <h5>
  //           All categories
  //         </h5>
  //         <p></p>
  //       </div>
  //     </div>
  //   </a>`
  // mainEl.appendChild(allCats)
  
  for (var i = 0; i < categories.length; i++) {
    // var mainEl = document.getElementById("main")
    var wrapper = document.createElement('DIV')
    wrapper.setAttribute('class', 'col-12 col-md-6 col-lg-4')
    wrapper.innerHTML =
      `<a href="<?php echo get_site_url(); ?>/category?city_id=${city_id}&category=${categories[i].name}" class="text-dark card-wrapper">
						<div class="card my-2 mx-md-2" style="">
							<img
								class="card-img-top"
								src="<?php echo get_stylesheet_directory_uri(); ?>/images/${categories[i].name}.png"
								alt=""
								loading="lazy"
								style="object-fit: cover; height: 180px; width: 100%;"
							/>
							<div class="card-body">
								<p class="card-text"></p>
								<h5>
									${categories[i].name}
								</h5>
								<p></p>
							</div>
						</div>
					</a>`

    mainEl.appendChild(wrapper)
  }
}
var initPlaces = function(places) {
  places.sort((a, b) => { return a.rating - b.rating })
  places = places.reverse()
  var mainEl = document.getElementById("places")
  for (var i = 0; i < places.length; i++) {
    var wrapper = document.createElement('li')
    wrapper.setAttribute('class', 'list-item')
    wrapper.innerHTML =
      `<b>
						<a
							class=""
							rel="nofollow noopener noreferrer"
							href="${places[i].map}"
						>
							<span class="badge bg-success text-white">
								${places[i].rating.toFixed(2)}
							</span>
						</a>
						<a
							class=""
							href="<?php echo get_site_url(); ?>/place?city_id=${city_id}&category=${category}&place_id=${places[i].place_id}"
							target="_blank"
							style="color: #000 !important; opacity: 80%;"
						>
							${places[i].name}</a>
					</b>
					<i class="">
						<small>(${places[i].user_total_rating} reviews)</small>
					</i>`

    mainEl.appendChild(wrapper)
  }
	if (places.length > 0) {

		var tip = document.createElement('DIV')
		tip.innerHTML = `<small class="" style="">
		Tip: Click on the
		<span class="badge badge-success"> rating </span> to open it on
		Google Maps
		</small>
		<br />
		<br />`
		mainEl.parentNode.appendChild(tip)
	} else {
    var noContent = document.createElement('DIV')
		noContent.innerHTML = 
    `<p class="text-dark" style="font-size: 18px;">
		No <b>${category}</b> found in this area.
		</p>`
		mainEl.parentNode.appendChild(noContent)
  }
}
var initPlace = function(place) {
  heading.innerHTML = place.name
	heading.classList.remove('text-white');
	heading.classList.add('text-dark');
	var background = document.getElementById("background")
	background.style.display = 'none';
	var jumbotron = document.getElementById("jumbotron")
	jumbotron.setAttribute('style', `
		background-color: #ffc53d !important;
		background-image: url(${api_base}/image?id=${place.photo}); 
		background-size: cover; 
		background-repeat: no-repeat; 
		background-position: center;
		background-blend-mode: overlay;
	`)
	
  var mainEl = document.getElementById("place")
  mainEl.innerHTML =
    `<div class="col-12 col-md-8">
				<div class="mb-3">
					<h2 class="">${ place.name }${ city ? " - " + city : "" }</h2>
					<hr />
				</div>
				<div class="mb-5">
					<p class="h4">Address</p>
					<span>${ place.address }</span>
				</div>
				<div class="mb-5">
					<p class="h4">Rating on Google Maps</p>
					<div>
						<h3 class="d-inline">
							<span class="badge bg-success text-white display-4">
								${ place.rating ? place.rating.toFixed(2) : "" }
							</span>
						</h3>
						<i>(${ place.user_total_rating } reviews)</i>
					</div>
					<!-- <span>${ place.stars }</span> -->
				</div>

				<div class="mb-5">
					<p class="h4">Working hours</p>
					<span>
						${ place.hour ? (place.hour.open_now ? "- Open Now" : "") : "" }
					</span>
				</div>
				<div class="mb-5">
					<p class="h4">Tags</p>
					<ul class="list-inline d-inline">
					` +
    Array.from(place.tags, (tag) => {
      return `<li class="list-inline-item bg-secondary text-white rounded px-2">
								${ tag }
							</li>`
    }).join('\n') +
    `
					</ul>
				</div>

			</div>
			<div class="col-12 col-md-4">
				<div class="mb-3">
					<a class="btn btn-block btn-success text-white" href="${place.map}">
						Open on Google Maps
					</a>
				</div>
				<div class="mb-3 bg-light w-100">
					<img src="${ api_base }/image?id=${ place.photo }" alt="" class="photo" loading="lazy" />
				</div>
			</div>`
}
var getCities = function() {
  var url = `${api_base}/api/cities`
  fetch(url, {
      method: 'GET',
      mode: 'cors',
      headers: {},
    })
    .then((response) => {
      if (!response.ok) {
        throw new Error(response.error)
      }
      return response.json();
    })
    .then(data => {
      console.log(data);
      autocomplete(document.getElementById("city"), data)
    })
    .catch(function(error) {
      console.log(error);
    });

}
var getCity = function() {
	var url = `${api_base}/api/city?id=${city_id}`
  fetch(url, {
      method: 'GET',
      mode: 'cors',
      headers: {},
    })
    .then((response) => {
      if (!response.ok) {
        throw new Error(response.error)
      }
      return response.json();
    })
    .then(data => {
      console.log(data);
			city = data.name 
      initHeader()
    })
    .catch(function(error) {
      console.log(error);
    });
}
var autocomplete = function(inp, arr) {
  var city_id_inp = inp.parentNode.querySelector('input[type=hidden]');
  console.log(city_id_inp);
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function(e) {
    var a,
      b,
      i,
      val = this.value;
    /*close any already open lists of autocompleted values*/
    closeAllLists();
    if (!val) {
      return false;
    }
    currentFocus = -1;
    /*create a DIV element that will contain the items (values):*/
    a = document.createElement("DIV");
    a.setAttribute("id", this.id + "autocomplete-list");
    a.setAttribute("class", "autocomplete-items");
    /*append the DIV element as a child of the autocomplete container:*/
    this.parentNode.appendChild(a);
    /*for each item in the array...*/
    for (i = 0; i < arr.length; i++) {
      /*check if the item starts with the same letters as the text field value:*/
      if (
        arr[i].name.substr(0, val.length).toUpperCase() == val.toUpperCase()
      ) {
        /*create a DIV element for each matching element:*/
        b = document.createElement("DIV");
        /*make the matching letters bold:*/
        b.innerHTML =
          "<strong>" + arr[i].name.substr(0, val.length) + "</strong>";
        b.innerHTML += arr[i].name.substr(val.length);
        /*insert a input field that will hold the current array item's value:*/
        b.innerHTML +=
          "<input type='hidden' value='" +
          arr[i].name +
          "' data-key='" +
          arr[i].id +
          "'>";
        /*execute a function when someone clicks on the item value (DIV element):*/
        b.addEventListener("click", function(e) {
          /*insert the value for the autocomplete text field:*/
          var elem = this.getElementsByTagName("input")[0];
          inp.value = elem.value;
          city_id_inp.value = elem.dataset["key"];
          document.getElementById("messages").innerHTML = ""
          /*close the list of autocompleted values,
          		(or any other open lists of autocompleted values:*/
          closeAllLists();
        });
        a.appendChild(b);
      }
    }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function(e) {
    var x = document.getElementById(this.id + "autocomplete-list");
    if (x) x = x.getElementsByTagName("div");
    if (e.keyCode == 40) {
      /*If the arrow DOWN key is pressed,
      	increase the currentFocus variable:*/
      currentFocus++;
      /*and and make the current item more visible:*/
      addActive(x);
    } else if (e.keyCode == 38) {
      //up
      /*If the arrow UP key is pressed,
      	decrease the currentFocus variable:*/
      currentFocus--;
      /*and and make the current item more visible:*/
      addActive(x);
    } else if (e.keyCode == 13) {
      /*If the ENTER key is pressed, prevent the form from being submitted,*/
      e.preventDefault();
      if (currentFocus > -1) {
        /*and simulate a click on the "active" item:*/
        if (x) x[currentFocus].click();
      }
    }
  });

  function addActive(x) {
    /*a function to classify an item as "active":*/
    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    if (currentFocus >= x.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = x.length - 1;
    /*add class "autocomplete-active":*/
    var topDist = x[currentFocus].offsetTop
    x[currentFocus].parentNode.scrollTop = topDist
    x[currentFocus].classList.add("autocomplete-active");
  }

  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }

  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document,
    except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
        x[i].parentNode.removeChild(x[i]);
      }
    }
  }
  /*execute a function when someone clicks in the document:*/
  document.addEventListener("click", function(e) {
    closeAllLists(e.target);
  });
}
var goToCity = function() {
  var form = document.getElementById("formCity")
  var inp = form.querySelector("input[type=hidden]")
  if (inp.value) {
    form.submit();
  }
  else {
    document.getElementById("messages").innerHTML = "You have to choose a city"

  }
}
jQuery(document).ready(function() {
	if (city_id) getCity()
	else initHeader()

  var url_part = ""
  if (page_temp == 'page-city.php') {
    url_part = "category";
  } else if (page_temp == 'page-category.php') {
    url_part = `category/${category}?city=${city_id}`
  } else if (page_temp == 'page-place.php') {
    url_part = `category/${category}/place?city=${city_id}&place_id=${place_id}`
  } else {

  }

  if (url_part) {
    var url = `${api_base}/api/${url_part}`


    fetch(url, {
        method: 'GET',
        mode: 'cors',
        headers: {},
      })
      .then((response) => {
        if (!response.ok) {
          throw new Error(response.error)
        }
        return response.json();
      })
      .then(data => {
        console.log(data);
        // return data;
        if (page_temp == 'page-city.php') {
          initCategories(data)
        } else if (page_temp == 'page-category.php') {
          initPlaces(data)
        } else if (page_temp == 'page-place.php') {
          initPlace(data)
        }
      })
      .catch(function(error) {
        console.log(error);
      });
  }
  getCities()

});
</script>
<script>

</script>
<?php 
}
add_action('wp_footer', 'my_script');



function mytheme_setup_options () {
	
}
add_action('after_switch_theme', 'mytheme_setup_options');